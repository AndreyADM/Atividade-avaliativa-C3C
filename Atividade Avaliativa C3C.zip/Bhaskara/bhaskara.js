/*Resolver a bhaskara

*/



const imputA = document.querySelector("#imputA");
const imputB = document.querySelector("#imputB");
const imputC = document.querySelector("#imputC");
const res1 = document.querySelector("#resultadoX1");
const res2 = document.querySelector("#resultadoX2");
const btn = document.querySelector("#calcular");
const aviso = document.querySelector("#aviso");



btn.onclick = () =>{  
    
    const ret = bhaskara (imputA.value, imputB.value, imputC.value);
    if(ret){
        res1.value = ret[0];
        res2.value = ret[1];
        aviso.innerText=""; 

    }else{
        aviso.innerText = "A equação nao possui raizes reais";
        
    }
    
}

//funçao calculo de bhaskara.
function  bhaskara (a, b, c) {
    
    //calcula delta, e as raizes x1, x2.
    const delta = (b**2)-(4*a*c);
    const x1 = (-b+(delta**(1/2)))/(2*a);
    const x2 = (-b-(delta**(1/2)))/(2*a);
    console.log(x1);
    console.log(delta);

    //se delta for menor que zero, nao a raiz.
    if(delta <0 ){
        return null;
    }

    return [x1, x2];

}


