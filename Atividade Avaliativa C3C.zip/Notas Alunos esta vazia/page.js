

const nota = document.querySelector("#nota");
const res = document.querySelector("#resultado");
const btn = document.querySelector("#calcular");
const l1 = document.querySelector("#l1");
const aviso = document.querySelector("#aviso");


//mostrar ao usuario que o campo esta vazio.
nota.onblur = () => {
    if(nota.value == ""){
        l1.style = "color:#ff0000";
        nota.style = "border-color: #030202";
    }else{
        l1.style = "colro:#030202";
        l1.style = "border-color:#030202";
    }
}

//faz a verificaçao dos valores inseridos e o arredondamento
btn.onclick = () =>{
   
    if(nota.value <0 || nota.value >100 ||nota.value == "" ){ // validaçao de ipmut
        nota.value = "";
        res.value = ""; 
        aviso.style = "#8f0101"
        aviso.innerText = "Somente valores de 0 a 100";

    }else if(nota.value <38){ //verifica se o aluno foi reprovado
        res.style = "color: #8f0101"
        res.value = "Nao foi dessa vez meu amiguinho";
    // Arredondamento da nota
    }else{
        const resto = Math.trunc(nota.value /5); //transforma divisao em inteiro
        const multiplo = (resto +1) *5; //obtençao do proximo multiplo
        const sobra = multiplo - nota.value; // obtem a diferença para o proximo multiplo e nota
        if(sobra <3){ //verifica se diferença da nota e o prox multiplo é <3
            res.value = multiplo;
        }else{
            res.value=nota.value
           
        }
        aviso.style = "color: #057d25"
        aviso.innerText = (`Parabens voce foi aprovado sua nota foi: ${res.value}`);
        
    }
}

   

