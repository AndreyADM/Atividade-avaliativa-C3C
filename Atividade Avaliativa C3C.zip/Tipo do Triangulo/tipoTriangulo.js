/*Verificar o tipo do triangulo

*/



const ladoA = document.querySelector("#ladoA");
const ladoB = document.querySelector("#ladoB");
const ladoC = document.querySelector("#ladoC");
const res = document.querySelector("#resultado");
const btn = document.querySelector("#calcular");
const aviso = document.querySelector("#aviso");


//testa se os valores estao vazioes e qual o tipo de triangulo
btn.onclick = () =>{
    console.log("ola mundo");
     if(ladoA.value <=0 || ladoB.value <=0 || ladoC.value <=0 ){
        ladoA.value = "";
        ladoB.value = "";
        ladoC.value = "";
        res.value = "";
        aviso.innerText = "Somente valores positivos maiores que zero";
    //verifica se todos os lados sao iguais
    }else if(ladoA.value == ladoB.value && ladoB.value == ladoC.value){
        res.value = "Equilatero" ;
        aviso.innerText = "";
    //Verifica se possui dois lados igauis
    }else if (ladoA.value == ladoB.value|| ladoB.value==ladoC.value|| ladoA.value == ladoC.value){
        res.value = "Isosceles" ;
        aviso.innerText = "";
    }else{
        res.value = "Escaleno";
        aviso.innerText = "";
    }
}


