//contagem de valores

const numero = document.querySelector("#numero");
const btn = document.querySelector("#contar");
const res = document.querySelector("#resultado");
const aviso = document.querySelector("#aviso")

btn.onclick = () => {
    if(numero.value == "" || numero.value <0 ){ // verifica se os valores sao vazios ou menores que zero
        aviso.value="Insira um numero inteiro, positivo valido";

    }else{
        res.innerText = contador(numero.value);
    }

}
//conta strings e verifica as condiçoes requeridas;
const contador = (n) => {
    const a = [];
    //laço itera  N vezes
    for(let i =1; i <= n; i++){
        //verificar se a iteraçao é divisivel por 5 e por 9.
        if(i %5 == 0 && i %9 == 0){
            a.push("LuidyMoura");
        }else if(i %5 == 0){ //verifica se a iteraçao e divisivel por 5.
            a.push("Luidy");
        }else if(i %9 == 0){ //verifica se a iteraçao e divisivel por 9.
            a.push("Moura");
        }else{
            a.push(i); //insere os resultados que nao condizem com o requisito (divisivel por 5, 9 ou pelos 2)
        }
    }
    return a;
}
